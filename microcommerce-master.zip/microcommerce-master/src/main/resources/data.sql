INSERT INTO product VALUES(1,'Ordinateur', 500 , 150 );
INSERT INTO product VALUES(2,'Aspirateur', 150 , 30 );
INSERT INTO product VALUES(3,'Table', 50 , 15 );
INSERT INTO product VALUES(4,'Smartphone', 1100 , 50 );